ALIF DIGITAL IDENTITY — STARTER WEBSITE

1. Upload index.html to a static website host (for example, GitHub Pages or Netlify).
2. After publishing, open your public website URL.
3. Paste that URL into the QR-code box and select Create QR code.
4. Save/share the generated QR code.

This is a self-created personal profile, not a government ID or proof of identity.
Only publish information you are comfortable sharing publicly. Do not add bank-card
numbers, PINs, OTPs, full home address, or national ID numbers.
